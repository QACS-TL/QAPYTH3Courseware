import warnings
#
# warnings.warn('Oops')
# print('Ending...')
#
#
# import warnings

def fxn():
    warnings.warn("deprecated", DeprecationWarning)
    print("The fxn function is running regardless")

# Will suppress warning message
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    fxn()

# Warning message will appear
fxn()
