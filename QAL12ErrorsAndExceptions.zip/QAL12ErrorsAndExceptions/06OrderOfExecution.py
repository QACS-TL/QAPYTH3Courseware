import sys

def my_func():
    try:
        f = open("foo")
        print("Everything is OK. If an error occurs we won't see this")
    except FileNotFoundError as err:
        print(err)

        # else is for running code if no exception is raised.
        # Try to think of it as a way to minimize your try block.
        # Sometimes you want to do additional stuff as a part of the try block,
        # but you want to keep the try block as minimal and specific as possible
    else:
        print("Everything is OK. If an error occurs we won't see this")
    finally:
        print("Finally block. We will ALWAYS see this", file=sys.stderr)

try:
    my_func()
except OSError:
    print("An OS error occurred", file=sys.stderr)

print("We are all done")
