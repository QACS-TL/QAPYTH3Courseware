import sys

def my_func(*arguments):
    if not all(arguments):
        raise ValueError('False argument in my_func')
    print("All is well in my_function")

try:
    my_func('Tom', '', 42)
except ValueError as err:
    print('Oops:', err, file=sys.stderr)
print("If error occurred it wil have been handled so we will always see this")
